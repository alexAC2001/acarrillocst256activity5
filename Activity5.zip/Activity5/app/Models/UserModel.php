<?php 
namespace App\Models;

use \JsonSerializable;
use PHPUnit\Util\Json;

class UserModel implements \JsonSerializable
{
    private $id;
    private $username;
    private $password;
    
    // Class Constructor
    public function __construct($username, $password, $id)
    {
        $this->id = $id;
        $this->username = $username;
        $this->password = $password;
    }   
    
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
    
    /**
     * Getter Method -> username
     */
    public function getUsername()
    {
        return $this->username;
    }
    /**
     * Getter Method -> password
     * @return string
     */
    public function getPassword()
    {
        return $this->password;
    }
    /**
     * Getter Method -> id
     * @return string
     */
    public function getId()
    {
        return $this->id;
    }
}