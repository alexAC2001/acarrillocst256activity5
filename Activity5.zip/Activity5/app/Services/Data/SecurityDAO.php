<?php
namespace App\Services\Data;

use App\Models\UserModel;
use Carbon\Exceptions\Exception;
use Illuminate\Support\Facades\Log;

class SecurityDAO
{
    // Define the connection string
    private $conn;
    private $servername = "localhost";
    private $username = "root";
    private $password = "root";
    private $dbname = "activity2";
    private $port = "";
    private $dbQuery;
    
    // Constructor that creates a connection with the database
    public function __construct()
    {
        // Create a connection to the database
        $this->conn = mysqli_connect($this->servername, $this->username, $this->password, $this->dbname);
        // Make sure to always test the connection and see if there are any errors. (Try catch?)
    }
    
    public function findByUser(UserModel $credentials)
    {
        try
        {
            // Define the query to search the database for the credentials
            $this->dbQuery = "SELECT Username, Password
                              FROM user
                              WHERE Username = '{$credentials->getUsername()}'
                              AND Password = '{$credentials->getPassword()}'";
            // If the selected query returns a resultset
            $result = mysqli_query($this->conn, $this->dbQuery);
            // If there are rows that are returned we have valid credentials
            if(mysqli_num_rows($result) > 0)
            {
                mysqli_free_result($result);
                mysqli_close($this->conn);
                return true;
            }
            else 
            {
                mysqli_free_result($result);
                mysqli_close($this->conn);
                return false;
            }
        
        } catch(Exception $e)
        {        
            Log::error("Exception in SecurityDAO" . $e->getMessage());
            echo $e->getMessage();
        }
    }
    
    // ----------For Activity 5----------
    public function findAllUsers()
    {
        $server = "localhost";
        $username = "root";
        $password = "root";
        $database = "activity2";
        $conn = mysqli_connect($server, $username, $password, $database);
        if(!$conn) {
            die("Connection Failed: " .mysqli_connect_error());
        }
        $sql = "SELECT * FROM user";
        $result = mysqli_query($conn, $sql);
        $users[UserModel::class] = array();
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                $users[] = $row;
            }
        }
        //print_r($users);     
        return $users;
    }
    
    public function findUserById($id)
    {
        $server = "localhost";
        $username = "root";
        $password = "root";
        $database = "activity2";
        $conn = mysqli_connect($server, $username, $password, $database);
        if(!$conn) {
            die("Connection Failed: " .mysqli_connect_error());
        }
        
        try
        {
            // Define the query to search the database for the credentials
            $dbQuery = "SELECT * FROM user
                              WHERE UserID = '$id'";
            // If the selected query returns a resultset
            $result = mysqli_query($conn, $dbQuery);
            // If there are rows that are returned we have valid credentials
            //if(mysqli_num_rows($result) > 0 && mysqli_num_rows($result) < 2)
            if($row = mysqli_fetch_assoc($result))
            {
                mysqli_free_result($result);
                echo "UserID: " . $row['UserID'] . "<br>";
                echo "Username: " . $row['Username'] . "<br>";
                echo "Password: " . $row['Password'] . "<br>";
                mysqli_close($this->conn);
                echo "Success!";
                return true;
            }
            else
            {
                mysqli_free_result($result);
                echo "The User does not exist";
                mysqli_close($this->conn);
                return false;
            }
            
        } catch(Exception $e)
        {
            echo $e->getMessage();
        }
        
    }
    
    public function findUserByIdTest2($id)
    {
        $server = "localhost";
        $username = "root";
        $password = "root";
        $database = "activity2";
        $conn = mysqli_connect($server, $username, $password, $database);
        if(!$conn) {
            die("Connection Failed: " .mysqli_connect_error());
        }
        $sql = "SELECT * UserID FROM user WHERE UserID = '$id'";
        $result = mysqli_query($conn, $sql);
        $users[UserModel::class] = array();
        // If the id exists, then print it out
        if (mysqli_) {
           // while ($row = mysqli_fetch_assoc($result)) {
                $users[] = $sql;
            //}
        }
        //print_r($users);
        return $users;
    }
    public function findUserByIdTest3($id)
    {
        $server = "localhost";
        $username = "root";
        $password = "root";
        $database = "activity2";
        $conn = mysqli_connect($server, $username, $password, $database);
        if(!$conn) {
            die("Connection Failed: " .mysqli_connect_error());
        }
        $id = intval($_GET['id']);
        $result = "SELECT * UserID FROM user WHERE UserID = '$id'";
        $row = mysqli_fetch_query($result);
        //$row_id = $row['id'];
        echo $row['id'];     
        header("www.example.com/index.php?id=$row_id");
        //return $users;
    }
}