<?php
namespace App\Services\Data;

use App\Models\CustomerModel;
use Carbon\Exceptions\Exception;
use App\Services\Data\Utility\DBConnect;

class CustomerDAO
{
    // Define the connection string
    private $connObject;
    private $dbname = "activity3";
    private $dbQuery;
    private $connection;
    private $dbObj;

    // Constructor that creates a connection with the database
    public function __construct($dbObj)
    {
        $this->dbObj = $dbObj;
/*         // Create a connection to the database
        // Creaet an instance of the class
        $this->conn = new DBConnect($this->dbname);
        // Call the method to create the connection
        $this->connection = $this->conn->getDbConnect(); */
    }
    
    // Method to add customer to the database
    public function addCustomer(CustomerModel $customerData)
    {
        try
        {
            // Define the query to search the database for the credentials
            $this->dbQuery = "INSERT INTO customer
                              (FirstName, LastName)
                              VALUES
                              ('{$customerData->getFirstName()}', '{$customerData->getLastName()}')";
            // If the selected query returns a resultset
            //$result = mysqli_query($this->conn, $this->dbQuery);
            // If there are rows that are returned we have valid credentials
            if($this->dbObj->query($this->dbQuery))
            {
                //$this->conn->closeDbConnect();
                return true; // Success
            }
            else
            {
                //$this->conn->closeDbConnect();
                return false; // Faliure
            }
            
        } catch(Exception $e)
        {
            echo $e->getMessage();
        }
    }
    
    // ACID
    // Get the next ID from the PK to put in the FK
    public function getNextID()
    {
        try
        {
            // Define the query to get the next ID
            $this->dbQuery = "SELECT CustomerID
                              FROM customer
                              ORDER BY CustomerID DESC LIMIT 0,1";
            
            $result = $this->dbObj->query($this->dbQuery);
            while ($row = mysqli_fetch_array($result))
            {   
                // Point to the next row that has not been committed yet.
                return $row['CustomerID'] + 1; // Getting the LAST CustomerID
            }
        }
        catch (Exception $e)
        {
            echo $e->getMessage();
        }
    }
    
}