<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\Data\Utility\ILoggerService;

class TestLoggingController extends Controller
{
    protected $logger;
    
    // Create a constructor that takes a iloggerservice argument
    
    public function __construct(ILoggerService $logger)
    {
        $this->logger = $logger;
    }
    
    public function index()
    {
        echo "In Index()<br/>";
        $this->logger->info("Entering TestLoggingController.index()"); // Comment for particpation and screenshot
        echo "Out of index()";
    }
}