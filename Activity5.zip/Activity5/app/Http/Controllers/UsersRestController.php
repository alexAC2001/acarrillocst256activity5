<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\Data\Utility\DBConnect;
use App\Models\UserModel;
use App\Services\Business\SecurityService;
use App\Models\DTO;
  


class UsersRestController extends Controller
{
    
    private $dto;
    private $ss;
      
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {        
        // Calling the method
        $ss = new SecurityService();
        $getUsers = $ss->getAllUsers();
        print_r($ss->getAllUsers()); 
        // DTO stuff
        $d = new DTO("Err101", "Error on index method!", "123");

        return json_encode($d);             
    }

    public function show($id)
    {
        // Calling the method
        $ss = new SecurityService();
        $getUser = $ss->getUser($id);
        //return $ss2->getUser($id);
        print_r($ss->getUser($id));        
        
        // DTO stuff
        $d = new DTO("Err303", "Error on show method!", "456");
        return json_encode($d); 
    }
    
    public function findAllUsers()
    {
        $server = "localhost";
        $username = "root";
        $password = "root";
        $database = "activity2";
        $conn = mysqli_connect($server, $username, $password, $database);
        if(!$conn) {
            die("Connection Failed: " .mysqli_connect_error());
        }
        $sql = "SELECT * FROM user";
        $result = mysqli_query($conn, $sql);
        $users[UserModel::class] = array();
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                $users[] = $row;
            }
        }
        print_r($users);      
    }
    
    
    
    
}


