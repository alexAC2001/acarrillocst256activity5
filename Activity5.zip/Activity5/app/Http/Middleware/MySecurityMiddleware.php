<?php

namespace App\Http\Middleware;

use Illuminate\Support\Facades\Log;
use Closure;

class MySecurityMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        // Step 1: You can use the following to get the route URI $request->path() or
        // we can also use $request->is();
        
        $path = $request->path();
        Log::info("Entering My Secuirty Middleware in handle() at path: " . $path);
        
        // Step 2: Run the business rules that check for the URI's that you do not need to secure.
        $secureCheck = true;
        if($request->is('/') || $request->is('login') || $request->is('dologin') || 
            $request->is('usersrest') || $request->is('usersrest/*') ||
            $request->is('loggingservice'))
            $secureCheck = false;
        Log::info($secureCheck ? "Security Middleware in handle()... Needs Security" :
            "Security Middleware in handle()... No security Required");
        // Step 3: If entering a secure URI with no security token then do a redirect to the login page
        if (session()->get('security') == 'enabled') 
            return $next($request);
        if($secureCheck)
        {
            Log::info("Leaving My Security Middleware in handle() doing a redirect to login");
            return redirect('/login');
        }
        
        return $next($request);
    }
}
