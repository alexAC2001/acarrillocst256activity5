<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Cache;

class MyTestMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        Log::info("Entering My test Middleware in handle()");
        // Using the data cache in Laravel
        // Step 1L Get an instance of one of the caches(in this case the file)
        // Step 2: Get a value from the cache and if the cache value is not there we will put it in the cache
        if($request->user_name != null)
        {
           Log::info("In not null....: " . $request->user_name); 
           $value = Cache::store("file")->get("mydata"); // going to the store cache and get the mydata (the key)
           if($value == null)
           {
               Log::info("Caching first time Username for: " . $request->user_name);
               Cache::store("file")->put("mydata", $request->user_name, 1); // Leave it there for 1 minute 
           }
        }
        else 
        {
            $value = Cache::store("file")->get("mydata");
            if($value != null)            
                Log::info("Getting Username from cache: " . $value);
              else 
                  Log::info("Could not get Username from Cache (data is older than 1 min)");
        }
        return $next($request);
    }
}
