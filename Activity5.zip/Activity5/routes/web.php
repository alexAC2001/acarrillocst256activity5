<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('index');
});


Route::get('/askme', function() {return view('whoami');});
// PART 1:
Route::get('/whoami', 'WhatsMyNameController@index');



// Route that will fire when we type in 'login' in the url
// This is just the name people will see on the outside
// as they type in the url.
Route::get('/login', function()
{
  echo("This is a test");
  // View 'loginView' has to be the name of the file in the views.
  return view('loginView');
});

// When the data is posted from the login page with 
// action set to 'dologin' it will come here.
// Then it will route the request to a function called index
// in the LoginController
Route::post('/dologin', 'LoginController@index');

// Route to add a customer
Route::get('/customer', function()
{
   return view('customer'); 
});
Route::post('/addcustomer', 'CustomerController@index');

//---------------------------------
// Route for add order
Route::get('/neworder', function()
{
   return view('order'); 
});
Route::post('/addorder', 'OrderController@index');

Route::get('/login2', function()
{
    return view('login2');
});


//------------Activity 5--------------
// Resourceful route
Route::resource('/usersrest', 'UsersRestController');
Route::get('/usersrest', 'UsersRestController@index')->name('UsersRestController.index');
Route::get('/usersrest{id}', 'UsersRestController@show')->name('UsersRestController.show');
// For testing purposes
Route::get('/allusers', 'UsersRestController@findAllUsers')->name('UsersRestController.find');
// Route to the restclientcontroller
Route::resource('/usersrestclient', 'RestClientController');
Route::get('/usersrestclient', 'RestClientController@index')->name('RestClientController.index');
Route::get('/usersrestclient{id}', 'RestClientController@index')->name('RestClientController.index');

// Logout route
Route::get('/logout', "LoginController@logout");

// Route for Activity 5 - Part 4
Route::get('/loggingservice', 'TestLoggingController@index');